package almonds;


public abstract class SaveCallback
{
	public abstract void done(ParseException e); 
}
