package almonds;

public abstract class DeleteCallback
{
	public abstract void done(ParseException e);	
}
