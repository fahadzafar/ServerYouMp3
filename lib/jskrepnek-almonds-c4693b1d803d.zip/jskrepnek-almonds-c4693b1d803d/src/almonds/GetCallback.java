package almonds;

public abstract class GetCallback
{
	public abstract void done(ParseObject object);
}
